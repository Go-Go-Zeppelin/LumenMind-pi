export async function resolve(specifier,context,nextResolve){
  if(specifier==='@earendil-works/pi-agent-core')return {url:new URL('./pi-mock.mjs',import.meta.url).href,shortCircuit:true};
  return nextResolve(specifier,context);
}
