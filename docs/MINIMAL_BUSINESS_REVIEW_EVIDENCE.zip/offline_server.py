import asyncio,json,os,pathlib,sqlite3,sys,datetime
sys.path.insert(0,'/path/to/LumenMind-pi/python-service')
from fastapi import FastAPI,Request
from business import store
from business.api import router
import uvicorn
OUT=pathlib.Path(__file__).parent
DB=OUT/'offline-business.sqlite3'
os.environ['BUSINESS_DB_PATH']=str(DB)
store.initialize(DB,True)
checks={}
with store.connect(DB) as c:
    checks['only_two_tables']={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}=={'orders','bills'}
    checks['foreign_keys_on']=c.execute('PRAGMA foreign_keys').fetchone()[0]==1
    checks['indexes']=set(r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='index'")) >= {'orders_user_id','bills_order_id'}
    checks['integer_amounts']=c.execute("SELECT count(*) FROM orders WHERE typeof(total_amount_cents)!='integer'").fetchone()[0]==0 and c.execute("SELECT count(*) FROM bills WHERE typeof(amount_cents)!='integer'").fetchone()[0]==0
    try:
        c.execute("INSERT INTO bills VALUES ('BAD','NO_ORDER',1,'CNY','unpaid',NULL,NULL,'2026-10-01T00:00:00+08:00')")
        checks['foreign_key_enforced']=False
    except sqlite3.IntegrityError:checks['foreign_key_enforced']=True
    c.execute("UPDATE orders SET product_name='independent-review-edited' WHERE order_id='ORD-1001-001'")
    c.execute("UPDATE bills SET payment_method='independent-review-edited' WHERE bill_id='BILL-1001-001'")
for _ in range(3):store.initialize(DB,True)
with store.connect(DB) as c:
    checks['idempotent_counts']=[c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in ['orders','bills']]==[4,4]
checks['seed_preserves_orders']=store.get_order(DB,'u1001','ORD-1001-001')['product_name']=='independent-review-edited'
checks['seed_preserves_bills']=store.get_bill(DB,'u1001','BILL-1001-001')['payment_method']=='independent-review-edited'
with store.connect(DB) as c:
    c.execute("INSERT INTO orders VALUES ('TIE-A','tie','A',1,100,'CNY','processing','2026-10-01T00:00:00+08:00')")
    c.execute("INSERT INTO orders VALUES ('TIE-B','tie','B',1,100,'CNY','processing','2026-10-01T00:00:00+08:00')")
    c.execute("INSERT INTO bills VALUES ('TIE-A','TIE-A',100,'CNY','unpaid',NULL,NULL,'2026-10-01T00:00:00+08:00')")
    c.execute("INSERT INTO bills VALUES ('TIE-B','TIE-B',100,'CNY','unpaid',NULL,NULL,'2026-10-01T00:00:00+08:00')")
checks['order_tie_sort']=[r['order_id'] for r in store.list_orders(DB,'tie')]==['TIE-B','TIE-A']
checks['bill_tie_sort']=[r['bill_id'] for r in store.list_bills(DB,'tie')]==['TIE-B','TIE-A']
(OUT/'offline-database-checks.json').write_text(json.dumps(checks,indent=2))
assert all(checks.values()),checks
app=FastAPI();app.include_router(router)
mode='normal'
@app.middleware('http')
async def record(request:Request,call_next):
    if request.url.path.startswith('/business'):
        if mode=='slow':await asyncio.sleep(.3)
        response=await call_next(request)
        with (OUT/'offline-http.jsonl').open('a') as f:f.write(json.dumps({'path':request.url.path,'query':dict(request.query_params),'status':response.status_code,'mode':mode})+'\n')
        return response
    return await call_next(request)
@app.post('/__review__/mode')
def set_mode(value:str):
    global mode
    mode=value;os.environ['BUSINESS_DB_PATH']=str(DB if value!='missing' else OUT/'absent-directory'/'business.sqlite3')
    return {'mode':mode}
@app.post('/memory/context')
def memory():return {'prompt_text':'','recent_messages':[],'relevant_history':[],'user_profile':{},'summary':''}
@app.post('/memory/turn')
def turn():return {'ok':True}
@app.get('/health')
def health():return {'status':'ok','review_only':True}
uvicorn.run(app,host='127.0.0.1',port=18080,log_level='warning')
