export class Agent {
  state={messages:[]};
  constructor(options){this.tools=options.initialState.tools;globalThis.__reviewConstructed.push(this.tools.map(t=>t.name));}
  subscribe(fn){this.sink=fn;}
  async prompt(message){
    let name=message.includes('账单')?'list_bills':'list_orders';
    let args={};
    if(message.includes('ORD-9999')){name='get_order';args={order_id:'ORD-9999-999'};}
    const tool=this.tools.find(t=>t.name===name);let result;
    if(tool){
      await this.sink({type:'tool_execution_start',toolName:name,toolCallId:'offline-call',args});
      let isError=false;
      try{result=await tool.execute('offline-call',args);}catch(e){isError=true;result={content:[{type:'text',text:e.message}]};}
      await this.sink({type:'tool_execution_end',toolName:name,toolCallId:'offline-call',result,isError});
      if(globalThis.__reviewFailBilling && this.tools.some(t=>t.name==='check_billing_fields'))throw new Error('offline simulated model interruption');
    }
    this.state.messages.push({role:'assistant',stopReason:'stop',content:[{type:'text',text:JSON.stringify({response:'演示查询结果 '+JSON.stringify(result?.details??{}),steps:[],required_info:[],escalate:false,diagnosis:'offline'})}]});
  }
}
