import concurrent.futures,datetime,json,pathlib,sqlite3,time,urllib.request,urllib.error,uuid
OUT=pathlib.Path(__file__).parent
ROOT=pathlib.Path('/path/to/LumenMind-pi')
DATA={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'api':[],'chats':[]}
def save(): (OUT/'live-evidence.json').write_text(json.dumps(DATA,ensure_ascii=False,indent=2))
def http(url,payload=None):
    data=None if payload is None else json.dumps(payload).encode()
    req=urllib.request.Request(url,data=data,headers={'content-type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=150) as r: return r.status,r.read().decode()
    except urllib.error.HTTPError as e: return e.code,e.read().decode()
def call(path,expected_status=200,check=lambda body:True):
    status,raw=http('http://localhost:8000'+path)
    body=json.loads(raw); passed=status==expected_status and check(body)
    item={'path':path,'status':status,'expected_status':expected_status,'response':body,'passed':passed}
    DATA['api'].append(item); save()
    print('API',path,status,'PASS' if passed else 'FAIL',flush=True)
    return body
conn=sqlite3.connect((ROOT/'data/business/business.sqlite3').as_uri()+'?mode=ro',uri=True);conn.row_factory=sqlite3.Row
expected={t:[dict(r) for r in conn.execute('SELECT * FROM '+t+' ORDER BY created_at DESC, '+('order_id' if t=='orders' else 'bill_id')+' DESC')] for t in ('orders','bills')};conn.close()
for resource in ('orders','bills'):
    for user,count in [('u1001',3),('u1002',1),('anonymous',0),('demo',0),('unknown',0)]:
        rows=[r for r in expected[resource] if (r.get('user_id') or next(x['user_id'] for x in expected['orders'] if x['order_id']==r['order_id']))==user]
        call(f'/business/{resource}?user_id={user}',check=lambda b,rows=rows,count=count:b=={'items':rows,'count':count,'source':'demo_business_db'})
    for limit in (1,2,20):
        call(f'/business/{resource}?user_id=u1001&limit={limit}',check=lambda b,limit=limit:b['count']==min(limit,3) and len(b['items'])==min(limit,3))
    for suffix in ('','?user_id=','?user_id=%20%20','?user_id=u1001&limit=0','?user_id=u1001&limit=21','?user_id=u1001&limit=bad','?user_id=u1001&limit=1.5'):
        call('/business/'+resource+suffix,422)
    prefix='ORD' if resource=='orders' else 'BILL'
    for number in ('1001-001','1001-002','1002-001'):
        identity='u1002' if number.startswith('1002') else 'u1001'
        row=next(x for x in expected[resource] if x[('order_id' if resource=='orders' else 'bill_id')]==prefix+'-'+number)
        call(f'/business/{resource}/{prefix}-{number}?user_id={identity}',check=lambda b,row=row:b=={'item':row,'source':'demo_business_db'})
    for identity,number in [('u1001','1002-001'),('u1001','9999-999'),('u1002','1001-001')]:
        call(f'/business/{resource}/{prefix}-{number}?user_id={identity}',404,lambda b:b=={'detail':'not_found'})
    call(f'/business/{resource}/{prefix}-1001-001',422)
call('/business/bills?user_id=u1001&order_id=ORD-1001-001',check=lambda b:b['count']==1 and b['items'][0]['bill_id']=='BILL-1001-001' and b['items'][0]['amount_cents']==12900)
call('/business/bills?user_id=u1001&order_id=ORD-1002-001',check=lambda b:b['items']==[])
call('/business/orders?user_id=u1001%27%20OR%201%3D1%20--',check=lambda b:b['items']==[])
status,raw=http('http://localhost:8000/openapi.json'); DATA['openapi_business_routes']=[p for p in json.loads(raw)['paths'] if p.startswith('/business')]
status,raw=http('http://localhost:3000/health');DATA['health']=json.loads(raw);save()

def chat(label,endpoint,user,message,tools,conv=None,stream=False):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();payload={'user_id':user,'conv_id':conv or 'independent-'+uuid.uuid4().hex,'message':message}
    item={'label':label,'endpoint':endpoint,'payload':payload,'expected_tools':tools,'started_at':started}
    try:
        status,raw=http(endpoint,payload);item['status']=status
        if stream:
            events=[]
            for block in raw.replace('\r\n','\n').split('\n\n'):
                if not block.strip():continue
                event=next((line[7:] for line in block.splitlines() if line.startswith('event: ')),None)
                value='\n'.join(line[6:] for line in block.splitlines() if line.startswith('data: '))
                if value:events.append({'event':event,'data':json.loads(value)})
            item['events']=events; result=next(e['data'] for e in events if e['event']=='done')
        else:result=json.loads(raw)
        item['response']=result
        _,trace_raw=http('http://localhost:3000/trace/tool/'+result['request_id']);trace=json.loads(trace_raw);item['trace']=trace
        checks={'http_ok':status==200,'trace_found':trace.get('found') is True,'trace_user':trace['trace']['user_id']==user.strip(),'trace_conv':trace['trace']['conv_id']==payload['conv_id'],'expected_tools':set(tools)<=set(result['tools_used']),'knowledge_false':result['knowledge_used'] is False,'output_valid':result.get('output_valid') is True,'response_equal_trace':result['response']==trace['trace']['response']}
        matches=[]
        for c in trace['trace']['tool_calls']:
            if c['tool_name'] not in ('list_orders','get_order','list_bills','get_bill'):continue
            from urllib.parse import urlencode,quote
            params={'user_id':user.strip()};args=c['input'];name=c['tool_name']
            if name.startswith('list_'):
                path='/business/'+('orders' if name=='list_orders' else 'bills');params['limit']=args.get('limit',10)
                if name=='list_bills' and 'order_id' in args:params['order_id']=args['order_id']
            else:
                key='order_id' if name=='get_order' else 'bill_id';path='/business/'+('orders' if name=='get_order' else 'bills')+'/'+quote(args[key],safe='')
            s,body=http('http://localhost:8000'+path+'?'+urlencode(params)); wanted=json.loads(body) if s==200 else {'found':False,'source':'demo_business_db'} if s==404 else None
            matches.append(wanted==c['output'] and c['success'] is True and c['is_error'] is False)
        checks['all_business_outputs_equal_live_api']=bool(matches) and all(matches)
        if stream:checks['sse_events']=all(n in [e['event'] for e in item['events']] for n in ['agent_start','tool_start','tool_end','done'])
        item['checks']=checks;item['passed']=all(checks.values())
    except Exception as e:item['error']=str(e);item['passed']=False
    item['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    return item
cases=[
('orders-list',8000,'u1001','查一下我的订单',['list_orders']),
('order-shipped',8000,'u1001','订单 ORD-1001-001 发货了吗？',['get_order']),
('bills-list',8000,'u1001','查看我的账单',['list_bills']),
('bills-filter',8000,'u1001','订单 ORD-1001-001 的账单',['list_bills']),
('bill-unpaid',8000,'u1001','查询账单 BILL-1001-002',['get_bill']),
('order-missing',8000,'u1001','查询订单 ORD-9999-999',['get_order']),
('order-foreign',8000,'u1001','查询订单 ORD-1002-001',['get_order']),
('native-user2',3000,'u1002','查一下我的订单',['list_orders']),
('native-unknown',3000,'unknown','查看我的账单',['list_bills']),
('native-composite',3000,'u1001','查一下我的订单和账单',['list_orders','list_bills'])]
for label,port,user,message,tools in cases:
    item=chat(label,f'http://localhost:{port}/chat',user,message,tools);DATA['chats'].append(item);save()
    print('CHAT',label,'PASS' if item['passed'] else 'FAIL',item.get('response',{}).get('request_id'),flush=True)
item=chat('native-stream','http://localhost:3000/chat/stream','u1001','订单 ORD-1001-001 发货了吗？',['get_order'],stream=True);DATA['chats'].append(item);save();print('CHAT native-stream',item['passed'],item.get('response',{}).get('request_id'),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    shared='independent-concurrent-'+uuid.uuid4().hex
    futures=[pool.submit(chat,'concurrent-'+u,'http://localhost:3000/chat',u,'查一下我的订单和账单',['list_orders','list_bills'],conv=shared) for u in ('u1001','u1002')]
    for future in futures:
        item=future.result();DATA['chats'].append(item);save();print('CHAT',item['label'],item['passed'],item.get('response',{}).get('request_id'),flush=True)
DATA['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({'api_passed':sum(x['passed'] for x in DATA['api']),'api_total':len(DATA['api']),'chats_passed':sum(x['passed'] for x in DATA['chats']),'chats_total':len(DATA['chats'])}),flush=True)
