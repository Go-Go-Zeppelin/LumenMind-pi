import assert from 'node:assert/strict';
import fs from 'node:fs';
import {config} from '/path/to/LumenMind-pi/agent-service/dist/src/config.js';
import {InfrastructureClient} from '/path/to/LumenMind-pi/agent-service/dist/src/clients/infrastructure.js';
import {LumenMindOrchestrator} from '/path/to/LumenMind-pi/agent-service/dist/src/agents/orchestrator.js';
import {PiAgentExecutor} from '/path/to/LumenMind-pi/agent-service/dist/src/agents/executor.js';
import {createApp} from '/path/to/LumenMind-pi/agent-service/dist/src/app.js';
import {AGENT_PROFILES} from '/path/to/LumenMind-pi/agent-service/dist/src/agents/profiles.js';
import {roleTools} from '/path/to/LumenMind-pi/agent-service/dist/src/tools/agent-tools.js';
import {createBusinessTools} from '/path/to/LumenMind-pi/agent-service/dist/src/tools/business-tools.js';
const out='/tmp/lumenmind-pi-independent-review.6LsoPy';
const cfg={...config,apiKey:'independent-offline-placeholder',useLlmRouting:false,useEmbeddingIntent:false,infrastructureUrl:'http://127.0.0.1:18080',infrastructureTimeoutMs:3000};
const infra=new InfrastructureClient(cfg.infrastructureUrl,3000), knowledge={name:'knowledge_search'};
const skills={promptFor:()=>'',matchedNamesFor:()=>[],summary:()=>({})};
globalThis.__reviewConstructed=[];globalThis.__reviewFailBilling=false;
let orchestrator;const evidence={mode:'real Express/FastAPI HTTP + actual sqlite3 SQL; only Pi model/events and memory mocked',cases:[]};
function make(){orchestrator=new LumenMindOrchestrator(cfg,infra,skills,knowledge);return createApp(cfg,orchestrator,skills,infra);}
let server=make().listen(18081,'127.0.0.1');
async function send(user,message='查看我的账单'){
 const response=await fetch('http://127.0.0.1:18081/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message,user_id:user,conv_id:'same-conversation'})});
 const result=await response.json();return {result,trace:orchestrator.getToolTrace(result.request_id)};
}
function checkUser(item,user){
 assert.equal(item.trace.user_id,user);assert.equal(item.result.knowledge_used,false);
 for(const c of item.trace.tool_calls){
  assert.equal(c.is_error,false);assert.equal(c.output.count,user==='u1001'?3:1);
  assert(c.output.items.every(row=>(row.order_id??'').includes(user==='u1001'?'1001':'1002')));
 }
}
try{
 for(const user of ['u1001','u1002']){const item=await send(' '+user+' ');checkUser(item,user);evidence.cases.push({name:'normal-'+user,passed:true,...item});}
 globalThis.__reviewFailBilling=true;
 const fallback=await send('u1002');checkUser(fallback,'u1002');assert.equal(fallback.result.agent_type,'general');assert.equal(fallback.trace.tool_calls.length,2);assert(fallback.trace.tool_calls.every(c=>c.fallback_used));evidence.cases.push({name:'billing-exception-fallback',passed:true,...fallback});
 globalThis.__reviewFailBilling=false;
 orchestrator.updateRoutingPenalties({billing_0:1});const monitor=await send('u1002');checkUser(monitor,'u1002');assert.equal(monitor.result.primary_agent,'general');evidence.cases.push({name:'monitor-fallback',passed:true,...monitor});
 orchestrator.updateRoutingPenalties({billing_0:0});
 const concurrent=await Promise.all(Array.from({length:8},(_,i)=>send(i%2?'u1002':'u1001')));
 concurrent.forEach((item,i)=>{checkUser(item,i%2?'u1002':'u1001');evidence.cases.push({name:'concurrent-'+i,passed:true,...item});});
 const missing=await send('u1001','查询订单 ORD-9999-999');assert.deepEqual(missing.trace.tool_calls[0].output,{found:false,source:'demo_business_db'});assert.equal(missing.trace.tool_calls[0].is_error,false);evidence.cases.push({name:'404-normal-found-false',passed:true,...missing});
 const executor=new PiAgentExecutor('general',cfg,knowledge,AGENT_PROFILES.general,roleTools('general'),infra);
 const input={message:'查一下我的订单',userId:'u1001',convId:'direct',memoryContext:'',skillPrompt:'',entities:{},allowKnowledge:false};
 const direct=await Promise.all([executor.run(input),executor.run({...input,userId:'u1002'})]);
 direct.forEach((result,i)=>{assert.equal(result.toolTraces[0].output.count,i?1:3);assert.equal(result.knowledgeUsed,false);assert(!globalThis.__reviewConstructed.at(-1).includes('knowledge_search'));evidence.cases.push({name:'shared-executor-no-knowledge-'+i,passed:true,result});});
 const technical=new PiAgentExecutor('technical',cfg,knowledge,AGENT_PROFILES.technical,roleTools('technical'),infra);await technical.run(input);assert(!globalThis.__reviewConstructed.at(-1).includes('list_orders'));assert.deepEqual(technical.availableToolNames(),AGENT_PROFILES.technical.tool_scope);evidence.cases.push({name:'technical-no-business-tools',passed:true});
 for(const tool of createBusinessTools(infra,'u1001')){assert(!('user_id' in tool.parameters.properties));assert.equal(tool.parameters.additionalProperties,false);}
 const own=await createBusinessTools(infra,'u1001')[0].execute('direct',{user_id:'u1002'});assert.equal(own.details.count,3);evidence.cases.push({name:'schema-and-model-user-override-ignored',passed:true});
 await fetch('http://127.0.0.1:18080/__review__/mode?value=missing',{method:'POST'});
 for(const path of ['orders','orders/ORD-1001-001','bills','bills/BILL-1001-001']){const r=await fetch('http://127.0.0.1:18080/business/'+path+'?user_id=u1001');assert.equal(r.status,503);assert.deepEqual(await r.json(),{detail:'business_unavailable'});}
 const failure=await executor.run(input);assert.equal(failure.toolTraces[0].is_error,true);assert.equal(failure.toolTraces[0].success,false);assert.equal(failure.knowledgeUsed,false);assert.equal(failure.toolsUsed.length,0);evidence.cases.push({name:'actual-db-connection-error-503-trace',passed:true,result:failure});
 await fetch('http://127.0.0.1:18080/__review__/mode?value=slow',{method:'POST'});
 const fast=new PiAgentExecutor('general',cfg,knowledge,AGENT_PROFILES.general,roleTools('general'),new InfrastructureClient(cfg.infrastructureUrl,30));
 const timeout=await fast.run(input);assert.equal(timeout.toolTraces[0].is_error,true);assert.match(timeout.toolTraces[0].error,/business_unavailable/);evidence.cases.push({name:'actual-http-timeout-trace',passed:true,result:timeout});
 await fetch('http://127.0.0.1:18080/__review__/mode?value=normal',{method:'POST'});
 evidence.passed=true;
}catch(error){evidence.passed=false;evidence.error=error.stack;process.exitCode=1;}
finally{fs.writeFileSync(out+'/offline-evidence.json',JSON.stringify(evidence,null,2));server.closeAllConnections();server.close();}
console.log(JSON.stringify({passed:evidence.passed,cases:evidence.cases.length,error:evidence.error}));
